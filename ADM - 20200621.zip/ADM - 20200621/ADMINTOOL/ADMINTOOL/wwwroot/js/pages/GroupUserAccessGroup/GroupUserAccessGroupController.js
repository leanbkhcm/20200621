﻿var root = angular.module('rootApp', ['masterApp', 'grpUserAccessGrpApp']);
var app = angular.module('grpUserAccessGrpApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);
app.controller('grpUserAccessGrpCtrl', function ($scope, $http, $interval) {
    $scope.currentLang = null;

    $http.get("/lang/" + currentLang + '.groupUserAccessGroup.json')
        .then(function (response) {
            $scope.site = response.data;
            //$scope.menuInit();
        });

    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.groupUserAccessGroup.json')
                .then(function (response) {
                    $scope.site = response.data;
                    //$scope.menuInit();
                });
        }
    }, 1000);



    $scope.checkBox = { status: 'disabled' };
    $scope.listCheckedAccessGrpID = [];
    $scope.allowCheckListFunctions = false;
    $scope.allowCheckListCommands = false;
    $scope.selectedCRUDGroupUserID = null;

    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    $scope.arrayAccessGroupIdJSONfromProject = [];
    $scope.arrayAccessGroupIdJSONfromAccessGroupID = [];
    $scope.arrayAccessGroupIdJSONtoCheckCheckBox = [];

    //get all projects
    $http.get(apiHost + 'AdmProject')
        .then(function (response) {
            $scope.projects = response.data;

            $scope.accessGroups = null;
            $scope.groupUsers = null;

            //if (projectId != null && projectId != '') {
            //    let index = $scope.projects.findIndex(project => project.projectID === projectId);
            //    if ($scope.projects[index] != null) {
            //        $scope.LoadAllDataByProject($scope.projects[index]);
            //    }
            //}
        });

    $scope.LoadAllDataByProject = function (project) {
        // reset it every time select project
        $scope.checkBox.status = 'disabled';
        $scope.selectedCRUDaccessGrpID = null;
        $scope.arrayAccessGrpsFromProject = [];//arrayFunctionCommandsFromProject
        $scope.arrayAccessGroupIdJSONfromProject = [];
        $scope.arrayAccessGroupIdJSONfromAccessGroupID = [];
        $scope.arrayAccessGroupIdJSONtoCheckCheckBox = [];
        $scope.listCheckedAccessGrpID = [];
        // end reset it every time select project

        $scope.selectedProject = project;

        //get All accessGroups
        $http.get(apiHost + 'AdmProject/GetPrjByPrjID?prjId=' + project.projectID)
            .then(function (response) {
                //$scope.accessGroups = response.data.admAccessGroups;
                $scope.groupUsers = response.data.admGroupUsers;
            });

        //get all accessGrps by projectID //<AdmAccessGroup>> GetAllAccessGrpsByProjectID
        $http.get(apiHost + 'AdmAccessGroup/GetAllAccessGrpsByProjectID?projectID=' + project.projectID)
            .then(function (response) {
                $scope.arrayAccessGrpsFromProject = response.data;
                for (var i in $scope.arrayAccessGrpsFromProject) {
                    $scope.arrayAccessGroupIdJSONfromProject.push({
                            "accessGroupID": $scope.arrayAccessGrpsFromProject[i].accessGroupID
                        });
                }
            });
    }



    ////get all function and commands by projectID
    //$http.get(apiHost + 'AdmFunction/GetAllFuncCommandsByProjectID?projectID=' + project.projectID)
    //    .then(function (response) {
    //        $scope.arrayFunctionCommandsFromProject = response.data;
    //        $scope.commands = null;
    //        for (var i in $scope.arrayFunctionCommandsFromProject) {
    //            var temp1 = $scope.arrayFunctionCommandsFromProject[i];
    //            for (var j in temp1.admCommands) {
    //                var temp2 = temp1.admCommands[j];

    //                //init all functions commands
    //                $scope.arrayAccessGroupIdJSONfromProject.push({
    //                    "commandID": temp2.commandID,
    //                    "functionID": temp2.functionID
    //                });
    //            }
    //        }
    //    });
    //}



    $scope.LoadAssignedGUAGByGrpUser = function (grpUser) {
            $http.get(apiHost + 'AdmGroupUser/GetDetailGroupUserBygrpID?grpID=' + grpUser.groupUserID)            
            .then(function (response) {
                // reset it every time select access group
                $scope.arrayAccessGroupIdJSONfromAccessGroupID = [];
                $scope.arrayAccessGroupIdJSONtoCheckCheckBox = [];
                $scope.listCheckedAccessGrpID = [];
                // end reset it every time select access group

                $scope.checkBox.status = 'enabled';
                //$scope.selectedAccessGroup = accessGroup;
                $scope.selectedCRUDGroupUserID = grpUser.groupUserID;
                $scope.arrayAssignedGrpUserAccessGrps = response.data;

                for (var i in $scope.arrayAssignedGrpUserAccessGrps) {
                    $scope.arrayAccessGroupIdJSONfromAccessGroupID.push({
                        "accessGroupID": $scope.arrayAssignedGrpUserAccessGrps[i].accessGroupID
                    });
                }

                //get matching                
                for (var i in $scope.arrayAccessGroupIdJSONfromProject) {
                    var temp4 = $scope.arrayAccessGroupIdJSONfromProject[i];
                    for (var j in $scope.arrayAccessGroupIdJSONfromAccessGroupID) {
                        var temp5 = $scope.arrayAccessGroupIdJSONfromAccessGroupID[j];
                        //push to tem array to setup checkbox
                        if (temp4.accessGroupID == temp5.accessGroupID) {
                            $scope.arrayAccessGroupIdJSONtoCheckCheckBox.push({
                                "accessGroupID": temp4.accessGroupID
                            });
                        }
                    }
                }

                $scope.listCheckedAccessGrpID = $scope.arrayAccessGroupIdJSONtoCheckCheckBox.map(item => {
                    return item.accessGroupID;
                })

                $scope.allowCheckListFunctions = true;
            });
    }

    $scope.autoCheckCheckBoxFunction = function (functionID) {

        if ($scope.allowCheckListFunctions === true) {

            for (var i in $scope.listCheckedAccessGrpID) {
                var tempFuncID = $scope.listCheckedAccessGrpID[i];
                if (tempFuncID == functionID) {
                    return true;
                }
            }
            $scope.allowCheckListFunctions = false;
        }

    }

    $scope.autoCheckCheckBoxCommand = function (commandID) {
        if ($scope.allowCheckListCommands === true) {
            for (var i in $scope.listCheckedCommands) {
                var tempCommandID = $scope.listCheckedCommands[i];
                if (tempCommandID == commandID) {
                    return true;
                }
            }
            $scope.allowCheckListCommands = false;
        }

    }

    $scope.handleClickAccessGrp = function (accessGrp) {
        if ($scope.selectedCRUDGroupUserID == null) {
            //$scope.listCheckedAccessGrpID = [];
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
            return;
        }
        $scope.selectedCRUDaccessGrpID = accessGrp.accessGroupID;
        //check functionID exist in listCheckedAccessGrpID or not
        var result = $scope.listCheckedAccessGrpID.includes($scope.selectedCRUDaccessGrpID);
        if (!result) {
            var tempListAssignedAccessGrps= [];

            for (var j in $scope.listCheckedAccessGrpID) {
                var tempAccessGrpID = $scope.listCheckedAccessGrpID[j];
                if (tempAccessGrpID == $scope.selectedCRUDaccessGrpID) {
                    tempListAssignedAccessGrps.push({
                        "accessGroupID": tempAccessGrpID
                    });
                }
            }

            function comparer(otherArray) {
                return function (current) {
                    return otherArray.filter(function (other) {
                        return other.accessGroupID == current.accessGroupID
                    }).length == 0;
                }
            }
            var arrayAccessGrpsJSONfromProjectGetByAccessGrpID = $scope.arrayAccessGroupIdJSONfromProject.filter(x => x.accessGroupID == $scope.selectedCRUDaccessGrpID);//arrayFunctionCommandJSONfromProjectGetByFuncID
            //var onlyInListAssignedFuncsCommands = tempListAssignedAccessGrps.filter(comparer($scope.arrayAccessGroupIdJSONfromProject));
            //var onlyInJSONfromProject = $scope.arrayAccessGroupIdJSONfromProject.filter(comparer(tempListAssignedAccessGrps));

            var onlyInListAssignedFuncsCommands = tempListAssignedAccessGrps.filter(comparer(arrayAccessGrpsJSONfromProjectGetByAccessGrpID));
            var onlyInJSONfromProject = arrayAccessGrpsJSONfromProjectGetByAccessGrpID.filter(comparer(tempListAssignedAccessGrps));

            var tempListUnAssignedAccessGrpID = onlyInListAssignedFuncsCommands.concat(onlyInJSONfromProject);

            //create for all Commands, except for Commands assigned
            for (var j in tempListUnAssignedAccessGrpID) {            
                var tempAccessGrpID = tempListUnAssignedAccessGrpID[j].accessGroupID;

                //create new access group function
                //existed $scope.selectedCRUDaccessGrpID so no need to set for it
                $scope.selectedCRUDaccessGrpID = tempAccessGrpID;
                $scope.CreateNewGrpUserAccessGrp();

                $scope.listCheckedAccessGrpID.push(tempAccessGrpID);
            }
        }
        else {//ok
            $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByAccessIDandFuncID?accessGrpID=' + $scope.selectedCRUDaccessGrpID
                + '&functionID=' + $scope.selectedCRUDaccessGrpID, null, 'application/json')
                .then(function (response) {
                    //swal("Deleted!", "Selected Access Group has been deleted!!!", "success")
                }, function (response) {
                    swal($scope.site.dg_error, response.data, "error");
                });

            ////update listFunctions commands 
            for (var i = $scope.listCheckedAccessGrpID.length - 1; i >= 0; i--) {
                if ($scope.listCheckedAccessGrpID[i] == $scope.selectedCRUDaccessGrpID) {
                    $scope.listCheckedCommands.splice(i, 1);//use one index for both list
                    $scope.listCheckedAccessGrpID.splice(i, 1);
                }
            }
        }
    }

    $scope.setSelectedCRUDCommand = function (command, isChecked) {

        $scope.selectedCRUDcommandID = command.commandID;

        $scope.selectedCRUDaccessGrpID = command.functionID;//auto set functionID based on commandID

        //if (command.isChecked) {  //temp remove 20200608

        if (isChecked) {
            $scope.CreateNewGrpUserAccessGrp();//ading 20200608
        }

        else {

            $scope.accessGroupFunction = {};

            $scope.accessGroupFunction.id = $scope.selectedCRUDaccessGrpID.toString() + command.functionID.toString() + command.commandID.toString();

            $scope.DeleteAccessGroupFunctionByAccessGrpFuncID($scope.accessGroupFunction.id);

        }

    }

    //anle add 20200609
    $scope.handleClickCommand = function (command) {
        if ($scope.selectedCRUDaccessGrpID == null) {
            $scope.listCheckedAccessGrpID = [];
            $scope.listCheckedCommands = [];
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
            return;
        }
        $scope.selectedCRUDcommandID = command.commandID;
        $scope.selectedCRUDaccessGrpID = command.functionID;//auto set functionID based on commandID

        //checked commandID exist in listCheckedCommands or not
        var result = $scope.listCheckedCommands.includes(command.commandID);
        if (!result) {
            $scope.CreateNewGrpUserAccessGrp();
            $scope.listCheckedCommands.push(command.commandID);
            $scope.listCheckedAccessGrpID.push(command.functionID);
        }
        else {
            $scope.accessGroupFunction = {};
            $scope.accessGroupFunction.id = $scope.selectedCRUDaccessGrpID.toString() + command.functionID.toString() + command.commandID.toString();
            $scope.DeleteAccessGroupFunctionByAccessGrpFuncID($scope.accessGroupFunction.id);

            //update listCheckedCommands

            const indexCommand = $scope.listCheckedCommands.indexOf(command.commandID);

            if (indexCommand > -1) {
                $scope.listCheckedCommands.splice(indexCommand, 1);
                $scope.listCheckedAccessGrpID.splice(indexCommand, 1);//use one index for both list
            }
        }
    }

    //click to functionID to get corresponding commands

    $scope.SelectCRUDfunctionToGetCRUDcommands = function (funct) {

        $http.get(apiHost + 'AdmCommand/GetCommandsByFuncID?id=' + funct.functionID)

            .then(function (response) {

                $scope.selectedCRUDaccessGrpID = funct.functionID;

                $scope.CRUDcommands = response.data;

            });

    }



    //click to command to set selected CommandID
    $scope.SelectCRUDCommand = function (command) {

        $scope.selectedCRUDcommandID = command.commandID;

        $scope.selectedCRUDaccessGrpID = command.functionID;//auto set functionID based on commandID

    }



    //get all commands according to functionID
    $scope.SelectAccessGroupProjectFunction = function (accessGroupProjectFunction) {
        $http.get(apiHost + 'AdmCommand/GetCommandsByFuncID?id=' + accessGroupProjectFunction.functionID)
            .then(function (response) {
                $scope.commands = response.data;
            });
    }



    $scope.SelectAccessGroupFunction = function (accessGrpFunc) {
        $scope.selectedAccessGroupFunction = accessGrpFunc;
    }

    $scope.CreateNewGrpUserAccessGrp = function () {
        if ($scope.selectedCRUDGroupUserID == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
            return;
        }

        $scope.grpUserAccessGrp = {};
        $scope.grpUserAccessGrp.accessGroupID = $scope.selectedCRUDaccessGrpID;
        $scope.grpUserAccessGrp.groupUserID = $scope.selectedCRUDGroupUserID;

        //$http.post(apiHost + 'AccessGroupFunction/', JSON.stringify($scope.accessGroupFunction), 'application/json')
        $http.post(apiHost + 'GroupUserAccessGroup/', JSON.stringify($scope.grpUserAccessGrp),'application/json')
            .then(function (response) {

                //$scope.accessGroupFunction = response.data;

                //$scope.accessGroupFunctions.push(response.data);//remove 20200610

                //reset 20200621
                $scope.accessGroupFunction = null;

                //$('#modalAccessGroupFunction').modal('hide');

                //swal("Success", "Access Group has been saved successfully", "success");

                //$scope.selectedCRUDcommandID = null;//reset 20200609

            }, function (response) {

                if (response.status == 500) {
                    swal($scope.site.dg_error, response.data + " . Error with status: 500 ", "error");
                }
                else {
                    swal($scope.site.dg_error + response.data, "error");
                }
            });
    }



    $scope.DeleteAccessGroupFunctionByAccessGrpFuncID = function (accessGrpFuncID) {

        //let index = $scope.accessGroupFunctions.findIndex(accessGroupFunction => accessGroupFunction.id === accessGrpFuncID);//error so temp remove 20200610

        $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByKeyID?id=' + accessGrpFuncID, null, 'application/json')

            .then(function (response) {

                //$scope.accessGroupFunctions.splice(index, 1);//temp remove 20200610

                //$scope.selectedCRUDcommandID = null;//reset 20200609

            }, function (response) {

                swal($scope.site.dg_error, response.data, "error");

            })

    }


    //no using
    $scope.DeleteAccessGroupFunction = function () {

        if ($scope.selectedAccessGroupFunction == null) {

            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");

        }

        else {

            swal({

                title: "are you sure?",

                text: "your will not be able to recover this Access Group Function!",

                type: "warning",

                showcancelbutton: true,

                confirmbuttoncolor: "#dd6b55", confirmbuttontext: "yes, delete it!",

                cancelbuttontext: "no, cancel it!",

                closeonconfirm: true,

                closeoncancel: true

            },

                function (isconfirm) {

                    if (isconfirm) {

                        //let index = $scope.accessGroupFunctions.findIndex(accessGroupFunction => accessGroupFunction.id === $scope.selectedAccessGroupFunction.id);//remove 20200610

                        $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByKeyID?id=' + $scope.selectedAccessGroupFunction.id, null, 'application/json').then(function (response) {

                            //$scope.accessGroupFunctions.splice(index, 1);//remove 20200610

                            //$scope.selectedCRUDcommandID = null;//reset 20200609

                            swal("Deleted!", "Selected Access Group Function has been deleted!!!", "success");

                        }, function (response) {

                            swal("error!", response.data, "error");

                        });

                    } else {
                    }
                });
        }
    }


    //no using
    $scope.SaveChanges = function () {
        //Create access group function
        if ($scope.selectedAccessGroupFunction == null) {

            $scope.accessGroupFunction = {};

            $scope.accessGroupFunction.id = $scope.inputAccessGrpFuncID;

            $scope.accessGroupFunction.accessGroupID = $scope.selectedCRUDaccessGrpID;

            $scope.accessGroupFunction.functionID = $scope.selectedCRUDaccessGrpID;

            $scope.accessGroupFunction.commandID = $scope.selectedCRUDcommandID;
            $http.post(apiHost + 'AccessGroupFunction/', JSON.stringify($scope.accessGroupFunction), 'application/json').then(function (response) {

                //alert(response.data);

                $scope.accessGroupFunction = response.data;

                //$scope.accessGroupFunctions.push(response.data);//remove 20200610

                $scope.accessGroupFunction = null;

                //$('#modalAccessGroupFunction').modal('hide');

                swal("Success", "Access Group has been saved successfully", "success");



            }, function (response) {

                if (response.status == 500) {

                    swal("Error", response.data + " . Error with status: 500 ", "error");

                }

                else {

                    swal("Error: " + response.data, "error");

                }

            });

        }
    }
})

app.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];
        if (angular.isArray(items)) {

            var keys = Object.keys(props);



            items.forEach(function (item) {

                var itemMatches = false;



                for (var i = 0; i < keys.length; i++) {

                    var prop = keys[i];

                    var text = props[prop].toLowerCase();

                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {

                        itemMatches = true;

                        break;

                    }

                }



                if (itemMatches) {

                    out.push(item);

                }

            });

        } else {

            // Let the output be the input untouched

            out = items;

        }
        return out;

    };

});