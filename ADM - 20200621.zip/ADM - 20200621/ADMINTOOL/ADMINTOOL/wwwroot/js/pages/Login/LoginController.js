﻿var app = angular.module('loginApp', []);
app.controller('loginCtrl', function ($scope, $http) {
    // Check if user is login before
    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    try {
        $scope.user = JSON.parse($scope.user);
        if ($scope.user != null) {
            window.location.href = firstScreen;
        }
    }
    catch (err) {

    }

    $scope.CheckLogin = function () {
        try {

            // Check if username / password is empty
            if ($scope.username == null || $scope.username.length <= 0
                || $scope.password == null || $scope.password.length <= 0
            ) {
                swal('Warning', 'Username / Password must not empty', 'warning');
                serverLog($scope.username, 'LOGIN', 'Username / Password must not empty', 'error');
            }
            // Check login
            else {
                $scope.user = {};
                $scope.user.userID = $scope.username;
                $scope.user.password = $scope.password;

                // Check token
                $scope.token = getSession('94a08da1fecbb6e8b46990538c7b50b2');
                if ($scope.token == null || $scope.token == 'undefined') {
                    GetToken($scope.user);
                    $scope.token = getSession('94a08da1fecbb6e8b46990538c7b50b2');
                    //token = $scope.token;
                }

                if ($scope.token != null && $scope.token != 'undefined') {
                    let payload = $scope.token.split('.')[1];
                    if (payload != null && payload != 'undefined') {
                        payload = JSON.parse(base64Decode(payload));

                        if ((payload.exp * 1000) < (new Date().getTime())) {
                            GetToken($scope.user);
                            $scope.token = getSession('94a08da1fecbb6e8b46990538c7b50b2');
                            //token = $scope.token;
                        }
                    }
                    else {
                        swal('Error', 'Get token failed. Please check your account!');

                        removeSession('94a08da1fecbb6e8b46990538c7b50b2');
                        serverLog($scope.username, 'LOGIN', 'Get token failed. Please check your account!', 'error');
                    }

                }

                if ($scope.token != null && $scope.token != 'undefined' && $scope.token.length > 0 && $scope.token.split('.')[1] != null && $scope.token.split('.')[1] != 'undefined') {
                    $http.defaults.headers.common['Authorization'] = 'Bearer ' + $scope.token;

                    $scope.user.password = EncryptText($scope.password);//anle temp remove 20200617 to test on local

                    $http.post(apiHost + 'admSpecialUser/isLoginValid', JSON.stringify($scope.user), 'application/json').then(function (response) {
                        // This function handles success
                        if (response.data == true) {
                            $scope.user.password = $scope.password;
                            setSession('ee11cbb19052e40b07aac0ca060c23ee', JSON.stringify($scope.user));
                            // Request token
                            GetToken($scope.user);
                            serverLog($scope.username, 'LOGIN', 'Login successfully', 'info');
                            window.location.href = firstScreen;

                        }
                        else {
                            swal('Error', 'Username / Password is incorrect. Try again!', 'error');
                            serverLog($scope.username, 'LOGIN', 'Username / Password is incorrect. Try again!', 'error');
                        }
                    }, function (response) {
                        // this function handles error
                        swal('Error', response.data, 'error');
                    });
                }
                else {
                    swal('Error', 'Get token failed. Please check your account!');
                    removeSession('94a08da1fecbb6e8b46990538c7b50b2');
                }

            }


        }
        catch (err) {
            swal('Error', err, 'error');
        }




    }

});