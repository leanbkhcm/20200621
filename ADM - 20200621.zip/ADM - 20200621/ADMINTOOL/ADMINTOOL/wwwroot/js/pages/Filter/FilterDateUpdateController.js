﻿app.filter('hideIfEmpty', function ($filter) {
    return function (dateString, format) {
        if (dateString.includes('01/01/0001 00:00')) {
            return "";
        }
        else {
            return $filter('date')(dateString, format.toString());
        }
    };
});