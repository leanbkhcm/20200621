﻿var root = angular.module('rootApp', ['masterApp', 'accessGroupApp']);
var app = angular.module('accessGroupApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);
app.controller('accessGroupCtrl', function ($scope, $http, $interval) {
    $scope.currentLang = null;
    $scope.inputAccessIdx = 1;//default index
    $scope.IsDisabledSaveBtn = true;//20200614
    //$scope.projectMenu = [];

    //Set timer to track language changes
    $http.get("/lang/" + currentLang + '.accessgroup.json')
        .then(function (response) {
            $scope.site = response.data;
            //$scope.menuInit();
        });
    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.accessgroup.json')
                .then(function (response) {
                    $scope.site = response.data;
                    //$scope.menuInit();
                });
        }
    }, 1000);

    $scope.StatusAcessGrp = {
        availableOptions: [
            { status: 'Active' },
            { status: 'Inactive' }
        ],
        selectedOption: { status: 'Active' } //This sets the default value of the select in the ui
    };

    $scope.selectedAccessGroup = null;
    $scope.selectedProject = null;
    $scope.selectedProjectID = null;
    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    //get all projects
    $http.get(apiHost + 'AdmProject/GetAllProject')
        .then(function (response) {
            $scope.projects = response.data;
        });
    
    $scope.LoadAccessGroupsBySelectedProject = function (prj) {
        $http.get(apiHost + 'AdmAccessGroup/GetAllAccessGrpsByProjectID?projectID=' + prj.projectID)
            .then(function (response) {
                $scope.accessGroups = response.data;
                $scope.selectedProject = prj;
                $scope.selectedProjectID = prj.projectID;
            });
    }

    $scope.SelectAccessGroup = function (accessGrp) {
        $scope.selectedAccessGroup = accessGrp;
        $scope.accessGroupID = accessGrp.accessGroupID;
        $scope.accessGroupName = accessGrp.accessGroupName;
        $scope.accessDescription = accessGrp.description;
        $scope.accessProjectID = accessGrp.projectID;
        $scope.accessIdx = accessGrp.idx;
        $scope.accessStatus = accessGrp.status;       
    }

    $scope.NewAccessGroup = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, "warning");
            return;
        }
        $scope.StatusAcessGrp.selectedOption.status = $scope.StatusAcessGrp.availableOptions[0].status;//20200611 set default active as create new //20200613 temp remove
        $scope.IsDisabledSaveBtn = true;//20200614
        $("#modalAccessGroup").modal({
            backdrop: 'static',
            keyboard: false
        });
        $('#modalAccessGroup').modal('show');   
        $scope.selectedAccessGroup = null;       
        $scope.accessGroupID = null;
        $scope.accessGroupName = null;
        $scope.accessDescription = null;

        //init as create new
        $scope.accessProjectID = $scope.selectedProjectID;
        $scope.accessIdx = $scope.inputAccessIdx;  
        $scope.accessStatus = $scope.StatusAcessGrp.selectedOption.status;//20200611 set default active as create new
    }

    $scope.EditAccessGroup = function () {
        if ($scope.selectedAccessGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp,  "warning");
        }
        else {
            $scope.StatusAcessGrp.selectedOption.status = $scope.selectedAccessGroup.status;//20200613 temp remove
            $scope.IsDisabledSaveBtn = false;//20200614
            $("#modalAccessGroup").modal({
                backdrop: 'static',
                keyboard: false
            });
            $('#modalAccessGroup').modal('show');
        }
    }

    $scope.DeleteAccessGroup = function () {
        if ($scope.selectedAccessGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
        }
        else {
            swal({
                title: $scope.site.dg_noticeDeleteAccessGrp + $scope.selectedAccessGroup.accessGroupName,
                //text: $scope.site.dg_noticeDeleteAccessGrp + $scope.selectedAccessGroup.accessGroupName,
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55", confirmButtonText: $scope.site.btn_ok,
                cancelButtonText: $scope.site.btncancel,
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isconfirm) {
                    if (isconfirm) {
                        let index = $scope.accessGroups.findIndex(accessGroup => accessGroup.accessGroupID === $scope.selectedAccessGroup.accessGroupID);//change to accessGroups
                        $http.delete(apiHost + 'Admaccessgroup/DeleteAccessGrpByAccessGrpID?grpId=' +          $scope.selectedAccessGroup.accessGroupID, null, 'application/json')
                            .then(function (response) {
                                swal($scope.site.dl_delete, $scope.site.dl_deletesuccess, "success");
                                $scope.accessGroups.splice(index, 1);       //change to accessGroups   
                                $scope.selectedAccessGroup = null;//add 20200614 to reset selectedAccGrp

                        }, function (response) {
                                    swal($scope.site.dg_error, response.data, "error");
                        });
                    } else {
                        //swal("cancelled", "cancelled!", "error");
                    }
                });
        }
    }

    //20200614
    $scope.EnableSavebtn = function () {  
        if ($scope.accessGroupName == null || $scope.accessIdx == null) {
            $scope.IsDisabledSaveBtn = true;
            return;
        }

        if (($scope.accessGroupName.length > 0) && ($scope.accessIdx > -1) && ($scope.accessIdx < 100)) //range for accessIdx is from 0 to 99
            $scope.IsDisabledSaveBtn = false;
        else
            $scope.IsDisabledSaveBtn = true;
    }

    $scope.SaveChanges = function () {
        //Create access group
        if ($scope.selectedAccessGroup == null) {
            $scope.accessGroup = {};
            $scope.accessGroup.accessGroupID = $scope.accessGroupID;
            $scope.accessGroup.accessGroupName = $scope.accessGroupName;
            $scope.accessGroup.description = $scope.accessDescription;
            $scope.accessGroup.projectID = $scope.selectedProjectID;//consider $scope.accessProjectID
            $scope.accessGroup.idx = $scope.accessIdx;//consider $scope.inputAccessIdx ;
            $scope.accessGroup.status = $scope.StatusAcessGrp.selectedOption.status;//default active  //consider $scope.StatusAcessGrp.selectedOption.status;
            $scope.accessGroup.userCreate = $scope.user.userID;
            $scope.accessGroup.dateCreate = new Date();

            $http.post(apiHost + 'AdmAccessGroup/', JSON.stringify($scope.accessGroup), 'application/json').then(function (response) {
                $scope.accessGroups.push(response.data);//change to accessGroups
                $scope.accessGroup = null;
                $scope.inputAccessIdx++;
                $scope.IsDisabledSaveBtn = true;//20200614
                $('#modalAccessGroup').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
            }, function (response) {
                if (response.status == 500) {
                    swal($scope.site.dg_error, response.data + " . Error with status: 500 ", "error");
                }
                else {
                    swal($scope.site.dg_error + response.data.title, response.data.errors, "error");
                }
            });
        }
        else {
            $scope.accessGroup = $scope.selectedAccessGroup;  

            //consider below fields 
            $scope.accessGroup.accessGroupID = $scope.accessGroupID;
            $scope.accessGroup.accessGroupName = $scope.accessGroupName;
            $scope.accessGroup.description = $scope.accessDescription;

            $scope.accessGroup.projectID = $scope.accessProjectID;//equal $scope.selectedProjectID 

            $scope.accessGroup.idx = $scope.accessIdx;//must be $scope.accessIdx, get from html
            $scope.accessGroup.status = $scope.StatusAcessGrp.selectedOption.status;//$scope.accessStatus;;//edited 20200611
            //$scope.accessGroup.status = $scope.accessStatus;
            $scope.accessGroup.userUpdate = $scope.user.userID;
            $scope.accessGroup.dateUpdate = new Date();

            $http.put(apiHost + 'AdmAccessGroup/UpdAccessGrpByAccessGrpId?accessGrpId=' + $scope.accessGroup.accessGroupID,
                JSON.stringify($scope.accessGroup), 'application/json')
                .then(function (response) {
                    $scope.accessGroup = null;
                    $scope.IsDisabledSaveBtn = true;//20200614
                $('#modalAccessGroup').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
            }, function (response) {
                if (response.status != 400) {
                    swal($scope.site.dg_error, response.data + " . Error with status: 500 ", "error");
                }
                else {
                    //swal("Error: " + response.data.title, response.data.errors.accessGroupName[0], "error");
                    swal($scope.site.dg_error + response.data, "error");
                }
            });
        }
        // swal("Error", "Project has not been saved", "error");
    }

    // Functions list
    $scope.AccessGroupFunctionList = function () {
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, 'warning');
        }
        //else if ($scope.selectedAccessGroup == null) {
        //    swal('Warning', 'Please select access group first', 'warning');
        //}
        else {
            window.location.href = '/AccessGroupFunction?projectId=' + $scope.selectedProjectID;
        }
    }
    // User Group list
    $scope.GroupUserAccessGroupList = function () {
        window.location.href = '/GroupUserAccessGroup';
    }

});

app.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];
        if (angular.isArray(items)) {
            var keys = Object.keys(props);
            items.forEach(function (item) {

                var itemMatches = false;
                for (var i = 0; i < keys.length; i++) {

                    var prop = keys[i];

                    var text = props[prop].toLowerCase();

                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {

                        itemMatches = true;

                        break;

                    }

                }
                if (itemMatches) {

                    out.push(item);

                }

            });

        } else {

            // Let the output be the input untouched

            out = items;

        }
        return out;

    };

});

//app.filter('hideIfEmpty', function ($filter) {
//    return function (dateString , format) {
//        if (dateString.includes('01/01/0001 00:00')) {
//            return "";
//        }
//        else {
//            return $filter('date')(dateString, format.toString());
//        }
//    };
//});