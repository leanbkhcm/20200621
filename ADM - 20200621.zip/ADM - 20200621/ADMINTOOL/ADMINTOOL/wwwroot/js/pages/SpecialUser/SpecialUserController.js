﻿var root = angular.module('rootApp', ['masterApp', 'userApp']);
var app = angular.module('userApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);
app.controller('userCtrl', function ($scope, $http, $interval) {
    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    $scope.currentLang = null;
    $scope.userMenu = [];
    $scope.IsDisabledSaveBtn = true;//20200615

    //Set timer to tracking language changes
    $http.get("/lang/" + currentLang + '.user.json')
        .then(function (response) {
            $scope.site = response.data;
            $scope.menuInit();
        });

    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.user.json')
                .then(function (response) {
                    $scope.site = response.data;
                    $scope.menuInit();
                });

        }
    }, 1000);

    //20200615
    $scope.StatusSpecialUser = {
        availableOptions: [
            { status: 'Active' },
            { status: 'Inactive' }
        ],
        selectedOption: { status: 'Active' } //This sets the default value of the select in the ui
    };

    //20200615
    $scope.RoleSpecialUser = {
        availableOptions: [
            { userRole: 'User' },
            { userRole: 'Admin' }
        ],
        selectedOption: { userRole: 'User' }
    };

    // Get projects list
    $http.get(apiHost + 'admproject')
        .then(function (response) {
            $scope.projects = response.data;
            // If has parameter: project
            if (projectId != null) {
                let index = $scope.projects.findIndex(project => project.projectID === projectId);
                if ($scope.projects[index] != null) {
                    $scope.LoadUserGroups($scope.projects[index]);
                }

            }
            //.If has parameter: project
            //console.log($scope.projects);
        });

    // Load Functions
    $scope.LoadUserGroups = function (project) {
        $http.get(apiHost + 'AdmProject/GetListGrpUserByPrjID?projectID=' + project.projectID)
            .then(function (response) {
                $scope.selectedProject = project;
                $scope.userGroups = response.data;
                $scope.selectedUserGroup = null;
                $scope.specialUsers = null;
                // If has parameter: Group
                if (groupId != null && groupId != '') {
                    let index = $scope.userGroups.findIndex(group => group.groupUserID === groupId);
                    if ($scope.userGroups[index] != null) {
                        $scope.LoadSpecialUsers($scope.userGroups[index]);
                    }

                }
                //.If has parameter: Group

            });
    }
    // Load Commands
    $scope.LoadSpecialUsers = function (group) {
        $http.get(apiHost + 'admspecialuser/GetUsersByGroupId?groupUserID=' + group.groupUserID)
            .then(function (response) {
                $scope.selectedUserGroup = group;
                $scope.specialUsers = response.data;

            });
    }


    //20200615
    $scope.EnableSavebtn = function () {
        if (($scope.userID == null) || ($scope.userName == null) || ($scope.userPassword == null)) {
            $scope.IsDisabledSaveBtn = true;
            return;
        }

        if (($scope.userID.length > 0) && ($scope.userName.length > 0) && ($scope.userPassword.length > 0)) 
            $scope.IsDisabledSaveBtn = false;
        else
            $scope.IsDisabledSaveBtn = true;
    }



    //$('#tableFunction').dataTable();
    // New function function
    $scope.NewUser = function () {
        //20200615
        if ($scope.selectedProject == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noproject, "warning");
            return;
        }
        if ($scope.selectedUserGroup == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nogroupuser, "warning");
            return;
        }

        //20200615
        $scope.StatusSpecialUser.selectedOption.status = $scope.StatusSpecialUser.availableOptions[0].status;
        $scope.RoleSpecialUser.selectedOption.userRole = $scope.RoleSpecialUser.availableOptions[0].userRole;
        $scope.IsDisabledSaveBtn = true;

        $("#modalUser").modal({
            backdrop: 'static',
            keyboard: false
        });

        $('#modalUser').modal('show');
        $scope.selectedUser = null;

        $scope.userID = null;
        $scope.userName = null;
        $scope.userDesc = null;
        //$scope.userRole = null;//removed 20200615
        //$scope.userStatus = null;//removed 20200615

        $scope.userStatus = $scope.StatusSpecialUser.selectedOption.status;//add 20200615
        $scope.userRole = $scope.RoleSpecialUser.selectedOption.userRole;//add 20200615

        $scope.userType = null;
        $scope.userPassword = null;
    }
    // Edit function function
    $scope.EditUser = function () {
        $scope.userPassword = null;
        if ($scope.selectedUser == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nouser, "warning");
        }
        else {
            //20200615
            $scope.StatusSpecialUser.selectedOption.status = $scope.selectedUser.status;
            $scope.RoleSpecialUser.selectedOption.status = $scope.selectedUser.userRole;
            $scope.IsDisabledSaveBtn = false;

            $("#modalUser").modal({
                backdrop: 'static',
                keyboard: false
            });

            $('#modalUser').modal('show');
        }
    }
    // Select Command
    $scope.SelectUser = function (specialUser) {
        $scope.selectedUser = specialUser;

        $scope.userID = specialUser.userID;
        $scope.userName = specialUser.username;
        $scope.userDesc = specialUser.fullName;
        $scope.userRole = specialUser.role;
        $scope.userStatus = specialUser.status;
        $scope.userType = specialUser.userType;

        $scope.userGroupModal = $scope.userGroups;

        $scope.selectedProjectModal = $scope.selectedProject;
        let index = $scope.userGroups.findIndex(group => group.groupUserID === specialUser.groupUserID);
        if ($scope.userGroups[index] != null) {
            $scope.selectedUserGroupModal = $scope.userGroups[index];
        }


    }

    // Delete function function
    $scope.DeleteUser = function () {
        if ($scope.selectedUser == null) {
            swal($scope.site.dl_warning, $scope.site.dg_nouser, "warning");
        }
        else {
            swal({
                title: $scope.site.dl_confirm,
                text: $scope.site.dl_notice,
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55", confirmButtonText: $scope.site.btn_ok,
                cancelButtonText: $scope.site.btncancel,
                closeOnConfirm: true,
                closeOnCancel: true
            },
                function (isConfirm) {
                    if (isConfirm) {
                        $http.delete(apiHost + 'admspecialuser/DeleteSpecialUser?userId=' + $scope.selectedUser.userID, null, 'application/json').then(function (response) {

                            // This function handles success
                            swal($scope.site.dg_success, $scope.site.dl_deletesuccess, "success");
                            let index = $scope.specialUsers.findIndex(specialUser => specialUser.userID === $scope.selectedUser.userID);
                            $scope.specialUsers.splice(index, 1);
                            $scope.selectedUser = null;
                            // alert(response.data);
                        }, function (response) {
                            // this function handles error
                            swal("Error!", response.data, "error");
                        });

                        //------------------

                    } else {
                        //swal("Cancelled", "Cancelled!", "error");
                    }
                });
        }
    }
    //Save changes
    $scope.SaveChanges = function () {
        // If create project
        if ($scope.selectedUser == null) {
            $scope.specialUser = {};
            $scope.specialUser.userID = $scope.userID;
            $scope.specialUser.username = $scope.userName;
            $scope.specialUser.fullName = $scope.userDesc;
            $scope.specialUser.role = $scope.userRole;
            //$scope.specialUser.status = $scope.userStatus;//removed 20200615
            $scope.specialUser.status = $scope.StatusSpecialUser.selectedOption.status;//add 20200615
            $scope.specialUser.userRole = $scope.RoleSpecialUser.selectedOption.userRole;//add 20200615

            $scope.specialUser.userType = $scope.userType;

            $scope.specialUser.password = EncryptText($scope.userPassword);
            $scope.specialUser.groupUserID = $scope.selectedUserGroup.groupUserID;
            
            $scope.specialUser.userCreate = $scope.user.userID;
            $scope.specialUser.dateCreate = new Date();

            $http.post(apiHost + 'admspecialuser/', JSON.stringify($scope.specialUser), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if create successfully
                //functDescription
                $scope.specialUser = response.data;
                $scope.specialUsers.push($scope.specialUser);
                $scope.specialUser = null;
                $scope.IsDisabledSaveBtn = true;//20200615

                $('#modalUser').modal('hide');
                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status == 500) {
                    swal("Error", response.data, "error");
                }
                else {
                    //swal("Error: " + response.data.title, response.data.errors.FunctionName[0], "error");
                    swal("Error:" + response.data.title, "error");
                }
                // console.log(response );
            });

            //------------------
        }
        // If update project
        else {
            $scope.specialUser = $scope.selectedUser;
            // $scope.project.projectID = $scope.projectCode;
            $scope.specialUser.fullName = $scope.userDesc;
            $scope.specialUser.role = $scope.userRole;
            //$scope.specialUser.status = $scope.userStatus;//removed 20200615
            $scope.specialUser.status = $scope.StatusSpecialUser.selectedOption.status;//add 20200615
            $scope.specialUser.userRole = $scope.RoleSpecialUser.selectedOption.userRole;//add 20200615

            $scope.specialUser.userType = $scope.userType;

            if ($scope.userPassword != null && $scope.userPassword.length > 0) {
                $scope.specialUser.password = EncryptText($scope.userPassword);
            }

            if ($scope.newUserGroup != null) //20200615
                $scope.specialUser.groupUserID = $scope.newUserGroup.groupUserID;

            $scope.specialUser.userUpdate = $scope.user.userID;
            $scope.specialUser.dateUpdate = new Date();

            $http.put(apiHost + 'admspecialuser/UpdateUser?userId=' + $scope.specialUser.userID, JSON.stringify($scope.specialUser), 'application/json').then(function (response) {
                // This function handles success
                //console.log(response);
                // if update successfully
                let index = $scope.specialUsers.findIndex(specialUser => specialUser.userID === $scope.specialUser.userID);
                $scope.specialUsers[index] = response.data;
                $scope.specialUser = null;
                $scope.IsDisabledSaveBtn = true;//20200615

                $('#modalUser').modal('hide');
               
                //20200615 add groupUserID to compare
                if ($scope.newUserGroup != null)
                    if ($scope.newUserGroup.groupUserID != $scope.selectedUserGroup.groupUserID) {
                    $scope.specialUsers.splice(index, 1);
                    }

                swal($scope.site.dg_success, $scope.site.dg_savesuccess, "success");
                // alert(response.data);
            }, function (response) {
                // this function handles error
                if (response.status != 400) {
                    swal("Error", response.data, "error");
                }
                else {
                    swal("Error: " + response.data.title, response.data.errors.FunctionName[0], "error");
                }
                // console.log(response );
            });

            //------------------

        }
    }

    $scope.menuInit = function () {
        // Menu context
        $scope.userMenu = [
            // NEW IMPLEMENTATION
            {
                text: $scope.site.btn_new,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.NewUser();
                }
            },
            {
                text: $scope.site.btn_edit,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectUser($itemScope.specialUser);
                    $scope.EditUser();
                }
            },
            {
                text: $scope.site.btn_delete,
                click: function ($itemScope, $event, modelValue, text, $li) {
                    $scope.SelectUser($itemScope.specialUser);
                    $scope.DeleteUser();
                }
            }


        ];
        //Menu context
    }

    // Load Functions
    $scope.LoadUserGroupModal = function (project) {
        $http.get(apiHost + 'AdmProject/GetListGrpUserByPrjID?projectID=' + project.projectID)
            .then(function (response) {
                $scope.userGroupModal = response.data;
            });
    }
    $scope.newUserGroup = null;//20200615 changed from [] to null
    $scope.SelectGroupModal = function (group) {
        //console.log(group);
        $scope.newUserGroup = group;
    }


});

app.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];

        if (angular.isArray(items)) {
            var keys = Object.keys(props);

            items.forEach(function (item) {
                var itemMatches = false;

                for (var i = 0; i < keys.length; i++) {
                    var prop = keys[i];
                    var text = props[prop].toLowerCase();
                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                        itemMatches = true;
                        break;
                    }
                }

                if (itemMatches) {
                    out.push(item);
                }
            });
        } else {
            // Let the output be the input untouched
            out = items;
        }

        return out;
    };
});