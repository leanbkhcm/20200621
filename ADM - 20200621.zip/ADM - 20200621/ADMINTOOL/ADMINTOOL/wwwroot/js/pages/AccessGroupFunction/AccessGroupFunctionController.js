﻿var root = angular.module('rootApp', ['masterApp', 'accessGroupFunctionApp']);
var app = angular.module('accessGroupFunctionApp', ['ngSanitize', 'ui.select', 'ui.bootstrap.contextMenu']);
app.controller('accessGroupFunctionCtrl', function ($scope, $http, $interval) {
    $scope.currentLang = null;

    $http.get("/lang/" + currentLang + '.accessgroupFunction.json')
        .then(function (response) {
            $scope.site = response.data;
            //$scope.menuInit();
        });
    $interval(function () {
        if (currentLang != $scope.currentLang) {
            $scope.currentLang = currentLang;
            $http.get("/lang/" + currentLang + '.accessgroupFunction.json')
                .then(function (response) {
                    $scope.site = response.data;
                    //$scope.menuInit();
                });
        }
    }, 1000);



    $scope.checkBox = { status: 'disabled' };
    $scope.listCheckedFunctions = [];
    $scope.allowCheckListFunctions = false;
    $scope.listCheckedCommands = [];
    $scope.allowCheckListCommands = false;
    $scope.selectedCRUDAccessGrpID = null;

    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');
    $scope.user = JSON.parse($scope.user);

    $scope.arrayFunctionCommandJSONfromProject = [];//20200806
    $scope.arrayFunctionCommandJSONfromAccessGroupID = [];//20200806
    $scope.arrayFunctionCommandJSONtoCheckCheckBox = [];//20200806

    //get all projects
    $http.get(apiHost + 'AdmProject')
        .then(function (response) {
            $scope.projects = response.data;
            $scope.accessGroups = null;
            $scope.commands = null;
            //adding 20200611
            // projectId passed from href by accessGroup. if it exists then do LoadAllDataByProject()
            if (projectId != null && projectId != '') {
                let index = $scope.projects.findIndex(project => project.projectID === projectId);
                if ($scope.projects[index] != null) {
                    $scope.LoadAllDataByProject($scope.projects[index]);
                }

            }

        });

    $scope.LoadAllDataByProject = function (project) {
        // reset it every time select project
        $scope.checkBox.status = 'disabled';
        $scope.selectedCRUDAccessGrpID = null;
        $scope.arrayFunctionCommandsFromProject = [];
        $scope.arrayFunctionCommandJSONfromProject = [];
        $scope.arrayFunctionCommandJSONfromAccessGroupID = [];
        $scope.arrayFunctionCommandJSONtoCheckCheckBox = [];
        $scope.listCheckedFunctions = [];
        $scope.listCheckedCommands = [];
        // end reset it every time select project

        $scope.selectedProject = project;

        //get All accessGroups
        $http.get(apiHost + 'AdmProject/GetPrjByPrjID?prjId=' + project.projectID)
            .then(function (response) {
                $scope.accessGroups = response.data.admAccessGroups;
                $scope.commands = null;
            });

        //get all function and commands by projectID
        $http.get(apiHost + 'AdmFunction/GetAllFuncCommandsByProjectID?projectID=' + project.projectID)
            .then(function (response) {
                $scope.arrayFunctionCommandsFromProject = response.data;
                $scope.commands = null;
                for (var i in $scope.arrayFunctionCommandsFromProject) {
                    var temp1 = $scope.arrayFunctionCommandsFromProject[i];
                    for (var j in temp1.admCommands) {
                        var temp2 = temp1.admCommands[j];

                        //init all functions commands
                        $scope.arrayFunctionCommandJSONfromProject.push({
                            "commandID": temp2.commandID,
                            "functionID": temp2.functionID
                        });
                    }
                }
            });
    }

    $scope.LoadAcessGrpFunctionsByAccessGrp = function (accessGroup) {
        $http.get(apiHost + 'Admaccessgroup/GetDetailAccessGrpFunctionByAccessGrpIDandProjectID?accessGrpID='
                            + accessGroup.accessGroupID + '&projectID=' + accessGroup.projectID)
            .then(function (response) {
                // reset it every time select access group
                $scope.arrayFunctionCommandJSONfromAccessGroupID = [];
                $scope.arrayFunctionCommandJSONtoCheckCheckBox = [];
                $scope.listCheckedFunctions = [];
                $scope.listCheckedCommands = [];
                // end reset it every time select access group

                $scope.checkBox.status = 'enabled';
                //$scope.selectedAccessGroup = accessGroup;
                $scope.selectedCRUDAccessGrpID = accessGroup.accessGroupID;
                $scope.arrayAssignedFunctionCommands = response.data;
             
                for (var i in $scope.arrayAssignedFunctionCommands) {
                    var temp3 = $scope.arrayAssignedFunctionCommands[i];
                    $scope.arrayFunctionCommandJSONfromAccessGroupID.push({
                        "commandID": temp3.commandID,
                        "functionID": temp3.functionID
                    });
                }

                ////get matching                
                for (var i in $scope.arrayFunctionCommandJSONfromProject) {
                    var temp4 = $scope.arrayFunctionCommandJSONfromProject[i];
                    for (var j in $scope.arrayFunctionCommandJSONfromAccessGroupID) {
                        var temp5 = $scope.arrayFunctionCommandJSONfromAccessGroupID[j];
                        //push to tem array to setup checkbox
                        if ((temp4.commandID == temp5.commandID) && (temp4.functionID == temp5.functionID)) {
                            $scope.arrayFunctionCommandJSONtoCheckCheckBox.push({
                                "commandID": temp4.commandID,
                                "functionID": temp4.functionID
                            });
                        }
                    }
                }

                $scope.listCheckedFunctions = $scope.arrayFunctionCommandJSONtoCheckCheckBox.map(item => {
                    return item.functionID;
                })

                $scope.listCheckedCommands = $scope.arrayFunctionCommandJSONtoCheckCheckBox.map(item => {
                    return item.commandID;
                })

                $scope.allowCheckListFunctions = true;
                $scope.allowCheckListCommands = true;
            });
    }

    $scope.autoCheckCheckBoxFunction = function (functionID) {

        if ($scope.allowCheckListFunctions === true) {

            for (var i in $scope.listCheckedFunctions) {
                var tempFuncID = $scope.listCheckedFunctions[i];
                if (tempFuncID == functionID) {
                    return true;
                }
            }
            $scope.allowCheckListFunctions = false;
        }

    }

    $scope.autoCheckCheckBoxCommand = function (commandID) {
        if ($scope.allowCheckListCommands === true) {
            for (var i in $scope.listCheckedCommands) {
                var tempCommandID = $scope.listCheckedCommands[i];
                if (tempCommandID == commandID) {
                    return true;
                }
            }
            $scope.allowCheckListCommands = false;
        }

    }

    $scope.handleClickFunction = function (arrayFunctionCommand) {
        if ($scope.selectedCRUDAccessGrpID == null) {
            //$scope.listCheckedFunctions = [];
            //$scope.listCheckedCommands = [];
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp , "warning");
            return;
        }
        $scope.selectedCRUDfunctionID = arrayFunctionCommand.functionID;
        //check functionID exist in listCheckedFunctions or not
        var result = $scope.listCheckedFunctions.includes($scope.selectedCRUDfunctionID);     
        if (!result) {
            var tempListAssignedFuncsCommands = [];

            //create temp List AssignedFuncsCommands
            for (var j in $scope.listCheckedFunctions) {
                //use one index j for both function and command, avoid loop list checked commands
                var tempFunctionID = $scope.listCheckedFunctions[j];
                if (tempFunctionID == $scope.selectedCRUDfunctionID) {
                    var tempCommandID = $scope.listCheckedCommands[j];
                    tempListAssignedFuncsCommands.push({
                        "commandID": tempCommandID,
                        "functionID": tempFunctionID
                    });
                }
            }

            function comparer(otherArray) {
                return function (current) {
                    return otherArray.filter(function (other) {
                        return other.commandID == current.commandID && other.functionID == current.functionID
                    }).length == 0;
                }
            }
            var arrayFunctionCommandJSONfromProjectGetByFuncID = $scope.arrayFunctionCommandJSONfromProject.filter(x => x.functionID == $scope.selectedCRUDfunctionID );
            //var onlyInListAssignedFuncsCommands = tempListAssignedFuncsCommands.filter(comparer($scope.arrayFunctionCommandJSONfromProject));
            //var onlyInJSONfromProject = $scope.arrayFunctionCommandJSONfromProject.filter(comparer(tempListAssignedFuncsCommands));

            var onlyInListAssignedFuncsCommands = tempListAssignedFuncsCommands.filter(comparer(arrayFunctionCommandJSONfromProjectGetByFuncID));
            var onlyInJSONfromProject = arrayFunctionCommandJSONfromProjectGetByFuncID.filter(comparer(tempListAssignedFuncsCommands));

            var tempListUnAssignedFuncsCommands  = onlyInListAssignedFuncsCommands.concat(onlyInJSONfromProject);

            //create for all Commands, except for Commands assigned
            for (var j in tempListUnAssignedFuncsCommands) {
                //use one index j for both function and command, avoid loop list checked commands
                var tempFunction = tempListUnAssignedFuncsCommands[j].functionID;
                var tempCommand =  tempListUnAssignedFuncsCommands[j].commandID;
                
                //create new access group function
                //existed $scope.selectedCRUDAccessGrpID so no need to set for it
                $scope.selectedCRUDfunctionID = tempFunction;
                $scope.selectedCRUDcommandID = tempCommand;
                $scope.CreateNewAccessGroupFunction();

                //update list checked functions and commands
                $scope.listCheckedFunctions.push(tempFunction);
                $scope.listCheckedCommands.push(tempCommand);
            }
        }
        else {//ok
            $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByAccessIDandFuncID?accessGrpID=' + $scope.selectedCRUDAccessGrpID
                + '&functionID=' + $scope.selectedCRUDfunctionID, null, 'application/json')
                .then(function (response) {
                    //swal("Deleted!", "Selected Access Group has been deleted!!!", "success")
                }, function (response) {
                        swal($scope.site.dg_error, response.data, "error");
                });

            ////update listFunctions commands 
            for (var i = $scope.listCheckedFunctions.length - 1; i >= 0; i--) {
                if ($scope.listCheckedFunctions[i] == $scope.selectedCRUDfunctionID) {
                    $scope.listCheckedCommands.splice(i, 1);//use one index for both list
                    $scope.listCheckedFunctions.splice(i, 1);
                }
            }
        }
    }

    $scope.setSelectedCRUDCommand = function (command, isChecked) {

        $scope.selectedCRUDcommandID = command.commandID;

        $scope.selectedCRUDfunctionID = command.functionID;//auto set functionID based on commandID

        //if (command.isChecked) {  //temp remove 20200608

        if (isChecked) {
            $scope.CreateNewAccessGroupFunction();//ading 20200608
        }

        else {

            $scope.accessGroupFunction = {};

            $scope.accessGroupFunction.id = $scope.selectedCRUDAccessGrpID.toString() + command.functionID.toString() + command.commandID.toString();

            $scope.DeleteAccessGroupFunctionByAccessGrpFuncID($scope.accessGroupFunction.id);

        }

    }

    //anle add 20200609
    $scope.handleClickCommand = function (command) {
        if ($scope.selectedCRUDAccessGrpID == null) {
            $scope.listCheckedFunctions = [];
            $scope.listCheckedCommands = [];
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
            return;
        }
        $scope.selectedCRUDcommandID = command.commandID;
        $scope.selectedCRUDfunctionID = command.functionID;//auto set functionID based on commandID

        //checked commandID exist in listCheckedCommands or not
        var result = $scope.listCheckedCommands.includes(command.commandID);
        if (!result) {
            $scope.CreateNewAccessGroupFunction();
            $scope.listCheckedCommands.push(command.commandID);
            $scope.listCheckedFunctions.push(command.functionID);
        }
        else {
            $scope.accessGroupFunction = {};
            $scope.accessGroupFunction.id = $scope.selectedCRUDAccessGrpID.toString() + command.functionID.toString() + command.commandID.toString();
            $scope.DeleteAccessGroupFunctionByAccessGrpFuncID($scope.accessGroupFunction.id);

            //update listCheckedCommands

            const indexCommand = $scope.listCheckedCommands.indexOf(command.commandID);

            if (indexCommand > -1) {
                $scope.listCheckedCommands.splice(indexCommand, 1);
                $scope.listCheckedFunctions.splice(indexCommand, 1);//use one index for both list
            }
        }
    }

    //click to functionID to get corresponding commands

    $scope.SelectCRUDfunctionToGetCRUDcommands = function (funct) {

        $http.get(apiHost + 'AdmCommand/GetCommandsByFuncID?id=' + funct.functionID)

            .then(function (response) {

                $scope.selectedCRUDfunctionID = funct.functionID;

                $scope.CRUDcommands = response.data;

            });

    }



    //click to command to set selected CommandID
    $scope.SelectCRUDCommand = function (command) {

        $scope.selectedCRUDcommandID = command.commandID;

        $scope.selectedCRUDfunctionID = command.functionID;//auto set functionID based on commandID

    }



    //get all commands according to functionID
    $scope.SelectAccessGroupProjectFunction = function (accessGroupProjectFunction) {
        $http.get(apiHost + 'AdmCommand/GetCommandsByFuncID?id=' + accessGroupProjectFunction.functionID)
            .then(function (response) {
                $scope.commands = response.data;
            });
    }



    $scope.SelectAccessGroupFunction = function (accessGrpFunc) {
        $scope.selectedAccessGroupFunction = accessGrpFunc;

        //$scope.projectCode = project.projectID;

        //$scope.projectName = project.projectName;

        //$scope.projectDesc = project.description;

        //$scope.projectStatus = project.status;

        //$scope.projectIdx = project.idx;

    }

    $scope.CreateNewAccessGroupFunction = function () {
        if ($scope.selectedCRUDAccessGrpID == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");
            return;
        }
        if ($scope.selectedCRUDfunctionID == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning"); 
            return;
        }

        if ($scope.selectedCRUDcommandID == null) {
            swal($scope.site.dl_warning, $scope.site.dg_noCommand, "warning");
            return;
        }

        $scope.accessGroupFunction = {};
        $scope.accessGroupFunction.accessGroupID = $scope.selectedCRUDAccessGrpID;
        $scope.accessGroupFunction.functionID = $scope.selectedCRUDfunctionID;
        $scope.accessGroupFunction.commandID = $scope.selectedCRUDcommandID;
        $scope.accessGroupFunction.id = $scope.accessGroupFunction.accessGroupID + $scope.accessGroupFunction.functionID + $scope.accessGroupFunction.commandID;
       
        $http.post(apiHost + 'AccessGroupFunction/', JSON.stringify($scope.accessGroupFunction), 'application/json')

            .then(function (response) {

                $scope.accessGroupFunction = response.data;

                //$scope.accessGroupFunctions.push(response.data);//remove 20200610

                $scope.accessGroupFunction = null;

                //$('#modalAccessGroupFunction').modal('hide');

                //swal("Success", "Access Group has been saved successfully", "success");

                //$scope.selectedCRUDcommandID = null;//reset 20200609

            }, function (response) {

                if (response.status == 500) {

                    swal($scope.site.dg_error, response.data + " . Error with status: 500 ", "error");

                }

                else {

                    swal($scope.site.dg_error + response.data, "error");

                }

            });
    }



    //adding 20200608

    $scope.DeleteAccessGroupFunctionByAccessGrpFuncID = function (accessGrpFuncID) {

        //let index = $scope.accessGroupFunctions.findIndex(accessGroupFunction => accessGroupFunction.id === accessGrpFuncID);//error so temp remove 20200610

        $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByKeyID?id=' + accessGrpFuncID, null, 'application/json')

            .then(function (response) {

                //$scope.accessGroupFunctions.splice(index, 1);//temp remove 20200610

                //$scope.selectedCRUDcommandID = null;//reset 20200609

            }, function (response) {

                    swal($scope.site.dg_error, response.data, "error");

            })

    }


    //no using
    $scope.DeleteAccessGroupFunction = function () {

        if ($scope.selectedAccessGroupFunction == null) {

            swal($scope.site.dl_warning, $scope.site.dg_noAccessGrp, "warning");

        }

        else {

            swal({

                title: "are you sure?",

                text: "your will not be able to recover this Access Group Function!",

                type: "warning",

                showcancelbutton: true,

                confirmbuttoncolor: "#dd6b55", confirmbuttontext: "yes, delete it!",

                cancelbuttontext: "no, cancel it!",

                closeonconfirm: true,

                closeoncancel: true

            },

                function (isconfirm) {

                    if (isconfirm) {

                        //let index = $scope.accessGroupFunctions.findIndex(accessGroupFunction => accessGroupFunction.id === $scope.selectedAccessGroupFunction.id);//remove 20200610

                        $http.delete(apiHost + 'AccessGroupFunction/DeleteAccessGrpFuncByKeyID?id=' + $scope.selectedAccessGroupFunction.id, null, 'application/json').then(function (response) {

                            //$scope.accessGroupFunctions.splice(index, 1);//remove 20200610

                            //$scope.selectedCRUDcommandID = null;//reset 20200609

                            swal("Deleted!", "Selected Access Group Function has been deleted!!!", "success");

                        }, function (response) {

                            swal("error!", response.data, "error");

                        });

                    } else {

                        //swal("cancelled", "cancelled!", "error");

                    }

                });

        }



    }


    //no using
    $scope.SaveChanges = function () {

        //Create access group function

        if ($scope.selectedAccessGroupFunction == null) {

            $scope.accessGroupFunction = {};

            $scope.accessGroupFunction.id = $scope.inputAccessGrpFuncID;

            $scope.accessGroupFunction.accessGroupID = $scope.selectedCRUDAccessGrpID;

            $scope.accessGroupFunction.functionID = $scope.selectedCRUDfunctionID;

            $scope.accessGroupFunction.commandID = $scope.selectedCRUDcommandID;
            $http.post(apiHost + 'AccessGroupFunction/', JSON.stringify($scope.accessGroupFunction), 'application/json').then(function (response) {

                //alert(response.data);

                $scope.accessGroupFunction = response.data;

                //$scope.accessGroupFunctions.push(response.data);//remove 20200610

                $scope.accessGroupFunction = null;

                //$('#modalAccessGroupFunction').modal('hide');

                swal("Success", "Access Group has been saved successfully", "success");



            }, function (response) {

                if (response.status == 500) {

                    swal("Error", response.data + " . Error with status: 500 ", "error");

                }

                else {

                    swal("Error: " + response.data, "error");

                }

            });

        }
    }
})

app.filter('propsFilter', function () {
    return function (items, props) {
        var out = [];
        if (angular.isArray(items)) {

            var keys = Object.keys(props);



            items.forEach(function (item) {

                var itemMatches = false;



                for (var i = 0; i < keys.length; i++) {

                    var prop = keys[i];

                    var text = props[prop].toLowerCase();

                    if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {

                        itemMatches = true;

                        break;

                    }

                }



                if (itemMatches) {

                    out.push(item);

                }

            });

        } else {

            // Let the output be the input untouched

            out = items;

        }
        return out;

    };

});