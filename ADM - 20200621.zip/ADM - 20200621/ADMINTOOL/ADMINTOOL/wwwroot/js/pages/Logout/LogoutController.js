﻿var app = angular.module('looutApp', []);
app.controller('looutApp', function ($scope, $http) {
    // Check if user is login before
    $scope.user = getSession('ee11cbb19052e40b07aac0ca060c23ee');

    $scope.logout = function () {

    }
});