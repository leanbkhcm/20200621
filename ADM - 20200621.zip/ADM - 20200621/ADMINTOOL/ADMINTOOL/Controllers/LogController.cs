﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using ADMINTOOL.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic.CompilerServices;
using SITV_LIB;

namespace ADMINTOOL.Controllers
{
    public class LogController : Controller
    {
        private IWebHostEnvironment hosting;
       // private IConfiguration config;
        public LogController(IWebHostEnvironment environment)
        {
            hosting = environment;
           // config = cfg;
        }
        [HttpPost()]
        // public IActionResult Index([FromBody]string logContent)
        public string Index([FromBody]Log log)
        {
            // SITV_LIB.SITV_LIB lib = new SITV_LIB.SITV_LIB();
            // IP: User đang sử dụng
            // string clientIP = Request.HttpContext.Connection.RemoteIpAddress.Address.ToString();
            //lib.ErrorLog(hosting.WebRootPath + "/Logs/", "192.168.1.22", "001", "Projects", "Lỗi load data");
            try
            {
                SITV_LIB.SITV_LIB lib = new SITV_LIB.SITV_LIB();
                log.Type = (string.IsNullOrEmpty(log.Type)) ? "info" : log.Type;
                log.Type = log.Type.ToLower();
                if (log.Type == "error")
                {
                    lib.ErrorLog(hosting.WebRootPath + "/Logs/logfile", log.ClientIP, log.UserName, log.Function, log.Message);
                }
                else if (log.Type == "warning")
                {
                    lib.WarningLog(hosting.WebRootPath + "/Logs/logfile", log.ClientIP, log.UserName, log.Function, log.Message);
                }
                else
                {
                    lib.InfoLog(hosting.WebRootPath + "/Logs/logfile", log.ClientIP, log.UserName, log.Function, log.Message);
                }
                return "OK";
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
           // new SITV_LIB.SITV_LIB().De("plain Text", true, "sitv");

        

            
        }
    }
}