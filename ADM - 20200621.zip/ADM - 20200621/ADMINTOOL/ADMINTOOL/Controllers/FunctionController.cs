﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ADMINTOOL.Controllers
{
    public class FunctionController : Controller
    {
        public IActionResult Index([FromQuery]string projectId)
        {
            if(projectId != null)
            {
                ViewBag.projectId = projectId;
            }
            return View();
        }
    }
}