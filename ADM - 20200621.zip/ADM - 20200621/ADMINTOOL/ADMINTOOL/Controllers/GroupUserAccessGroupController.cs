﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADMINTOOL.Controllers
{
    public class GroupUserAccessGroupController : Controller
    {
        public IActionResult Index(/*[FromQuery]string projectId, [FromQuery]string accessGroupId*/)
        {
            //if (projectId != null)
            //{
            //    ViewBag.projectId = projectId;
            //}
            //if (accessGroupId != null)
            //{
            //    ViewBag.accessGroupId = accessGroupId;
            //}
            return View();
        }
    }
}
