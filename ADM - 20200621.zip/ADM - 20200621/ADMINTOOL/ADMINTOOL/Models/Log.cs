﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ADMINTOOL.Models
{
    public class Log
    {
        public string ClientIP { get; set; } 
        public string UserName { get; set; } 
        public string Function { get; set; } 
        public string Message { get; set; } 
        public string Type { get; set; } 
    }
}
